//Snap Assembly Tarp Grommet...Randy Ohman, aka TallTeacherGuy aka JSTEM...January 2018
//The idea is to provide a slip fit of the closing snap over the grommet until the toroids have to squeeze past each other. Chamfers have been added to make edges friendly to the tarp at the periphery of the flanges. A hole must be cut or punched in the tarp to accommodate this grommet. I haven't tried jacking with the variables to see if everything else falls in line so do some quality control testing if you need to alter size. It should be close though.


//variables for grommet
thrurad=6;
thruwall=2;
flangethk=2;
flangerad=14;
hght=8;
//variables for snap
clear=.7;
snapwall=1.5*thruwall;
snaphght=hght-flangethk;
torrad=.6*thruwall;

grommet();
snap();

module grommet(){
//grommet main bore
difference(){
cylinder(h=hght,r=thruwall+thrurad);
cylinder(h=hght,r=thrurad,$fn=40);
cylinder(hght,thruwall+thrurad,0,$fn=40);
}
//adding the flange
difference(){
cylinder(h=flangethk,r=flangerad);
cylinder(h=flangethk,r=thruwall+thrurad);
//outer tarp deburr toroid
translate([0,0,1*flangethk])
rotate_extrude(convexity = 10, $fn = 100)
translate([flangerad, 0, 0])
rotate([0,0,60])circle(r = flangethk, $fn = 3);
}
//toroid on grommet for snap action
translate([0,0,hght])
rotate_extrude(convexity = 10, $fn = 100)
translate([thruwall+thrurad-.7*torrad, 0, 0])
circle(r = torrad, $fn = 100);


}

module snap(){
translate([2.05*flangerad,0,0]){
//snap main cylinder
difference(){
cylinder(h=.55*hght,r=thruwall+thrurad+.3*torrad+1.5*thruwall);
cylinder(h=.55*hght,r=thruwall+thrurad+clear);
}
//adding the flange
difference(){
cylinder(h=flangethk,r=flangerad);
cylinder(h=flangethk,r=thruwall+thrurad+.3*torrad+1.5*thruwall);
//outer tarp deburr toroid
rotate_extrude(convexity = 10, $fn = 100)
translate([flangerad, 0, 0])
rotate([0,0,60])circle(r = flangethk, $fn = 3);
}
//toroid on snap for snap action
translate([0,0,.5*hght])
rotate_extrude(convexity = 10, $fn = 100)
translate([thruwall+thrurad+1.1*torrad, 0, 0])
circle(r = torrad, $fn = 100);
}
}
